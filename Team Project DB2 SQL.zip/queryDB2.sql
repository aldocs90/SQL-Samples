#JOIN QUERIES

#1 Green total score with Continent List, and population index

#Alter Table 1
use teamproject;

update continent_list
set country_id= "United States"
where continent="North America" and country_id="US";

#Alter Table 2

update continent_list
set country_id= "Russia"
where continent="Asia" and country_id="Russian Federation";

#2 Green total score with Continent List, and population index - 1st Join

select country_id, total_emissions, total_energy_transition, total_green_society, total_clean_innovation, total_climate_policy, continent, population_2020, population_rank
from green_totalscores gts
join continent_list cl
using (country_id)
join population_index pi
on cl.country_id = pi.country
where population_2020 <= 6000000
order by population_rank desc;


# Emissions transport between the most populated countries - 2nd part

select country_id, population_2020, emissions_transport, carbon_growth, meat_diary_consume, renewable_energy
from carbon_emissions ce
join population_index pi
on ce.country_id = pi.country
join green_society gs
using (country_id)
join energy_transition et
using (country_id)
where population_2020 >= 200000000
order by population_2020 desc;

#2nd Join - Efforts from countries in Enviromental Policies - Sorting by the advancement in patents
select country_id, green_buildings, recycling_efforts, forestation_change, renewable_energy, renewable_contribution, patents
from green_society gs
join energy_transition et
using (country_id)
join clean_innovation
using (country_id)
where patents > 5
order by patents desc;



#SUBQUERIES

#subquery using select - Pandemic Pivot comparison with renewable contribution
create view v4 as 
select country_id, renewable_contribution, 
(select pandemic_pivot
from climate_policy
where country_id = et.country_id and pandemic_pivot<= 5) as Pandemic_Pivot_Low
from energy_transition et
order by Pandemic_Pivot_Low asc;

select *
from v4
where Pandemic_Pivot_Low is not null;

#subquery using from clause - Diary and meat consumption 

select  continent, avg(meat_diary_consume) as Avg_Meat_Diary_Consumption
from (select *
from green_society gs
join continent_list cl
using (country_id)) as gs_cl
where meat_diary_consume is not null
group by continent
order by Avg_Meat_Diary_Consumption desc;

#subquery using where clause -

select country_id, green_buildings, continent 
from green_society gs 
where continent in (
select continent 
from continent_list cl
where continent="Europe"
);


#subquery using free clause-


create view v5 as
select country_id,agriculture_strategy,(
select forestation_change
from green_society gs
where country_id = cp.country_id and forestation_change < 4
and forestation_change is not null) as Forestation_Change_1
from climate_policy cp;

select * from v5 
where Forestation_Change_1 is not null;

 SET FOREIGN_KEY_CHECKS=0;
 CREATE TABLE `continent_list` (
   `continent` varchar(50) NOT NULL,
   `country_id` varchar(50) NOT NULL,
    PRIMARY KEY (`country_id`)
 );

SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE `carbon_emissions` (
    `country_id` varchar(50) NOT NULL,
  `carbon_emissions` decimal(20,2) ,
  `carbon_growth` decimal(20,2) ,
  `emissions_transport` decimal(20,2) ,
  `emissions_industry` decimal(20,2) ,
  `emissions_agriculture` decimal(20,2) ,
  PRIMARY KEY (`country_id`)
  );
  
SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE `clean_innovation` (
    `country_id` varchar(50) NOT NULL,
  `patents` decimal(20,2) ,
  `energy_investment` decimal(20,2) ,
  `foodtech_investment` decimal(20,2) ,
  PRIMARY KEY (`country_id`)
  );
SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE `climate_policy` (
    `country_id` varchar(50) NOT NULL,
	`climate_action` decimal(20,2),
  `carbon_pricing` decimal(20,2) ,
  `agriculture_strategy` decimal(20,2) ,
  `pandemic_pivot` decimal(20,2) ,
  PRIMARY KEY (`country_id`)
 );

SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE `energy_transition` (
    `country_id` varchar(50) NOT NULL,
	`renewable_energy` decimal(20,2),
  `renewable_contribution` decimal(20,2) ,
  PRIMARY KEY (`country_id`)
);

SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE `green_society` (
    `country_id` varchar(50) NOT NULL,
	`green_buildings` decimal(20,2),
  `recycling_efforts` decimal(20,2) ,
   `forestation_change` decimal(20,2) ,
    `meat_diary_consume` decimal(20,2) ,
  PRIMARY KEY (`country_id`)
);

SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE `green_totalscores` (
    `country_id` varchar(50) NOT NULL,
	`total_emissions` decimal(20,2),
  `total_energy_transition` decimal(20,2) ,
   `total_green_society` decimal(20,2) ,
    `total_clean_innovation` decimal(20,2) ,
    `total_climate_policy` decimal(20,2) ,
    `green_index` decimal(20,2) ,
  PRIMARY KEY (`country_id`)
);

SET FOREIGN_KEY_CHECKS=0;
CREATE TABLE `population_index` (
  `country` varchar(50) NOT NULL,
  `population_2021` decimal(20,2) ,
  `population_2020` decimal(20,2) ,
  `population_rank` decimal(20,2) ,
  PRIMARY KEY (`country`)
  );