use classicmodels ;



#1.2 
-- 1）quary the names of all the sales rep
select firstname,lastname
from employees
where jobtitle='Sales Rep';

-- 2）Find all customer data whose postcode is null.
select customerName, postalCode
from customers 
where postalCode IS NULL;

#1.3 
-- 1）query  all customers with dec in their name
select customername
from customers
where customername like '%dec%' ;

-- 2）Identify all the disputed items which have been returned.
select ordernumber, status, productname
from orders, products 
where status like "Disputed";

#1.4
-- 1） A customer wants to know about our motorcycle model products.Please check for him, the names and prices of all motorcycle models
select productname,productline,msrp
from products
where productline regexp 'Motorcycles' ;

-- 2）Business case:  Some of our customers have problems with their credit limits which caused outstanding payments and back orders until we receive their payment. In order to maintain the relationship with customers (making our clients or cooperating companies feel valued ) and to avoid having bad debts, we have to identify these customers or companies and contact them for further detail about their isseu.. 

select 
c.customerName,c.creditLimit, o.comments, 
o.status
from customers c
join orders o
on c.customerNumber = o.customerNumber
where status REGEXP 'on Hold$';

#1.5 Join
-- 1）  Sales want to know each customer's comments and call them back
select c.customername,o.comments,c.phone
from customers c
left join orders o
on  c.customernumber=o.customernumber 
where comments is not null ;

-- 2）Query the total cost of each user who has placed an order
select c.customernumber,c.customername,sum(od.priceeach)as total
from customers c
join orders o
on c.customernumber= o.customernumber 
join orderdetails od
on od.ordernumber= o.ordernumber 
group by c.customernumber
order by total desc ;

-- 3）Find out all the customers who have returned products before.
select customerName, productName, status 
from customers c
join orders o
on c.customerNumber = o.customerNumber
join orderdetails r
on o. orderNumber = r. orderNumber
join products p
on r. productCode = p. productCode
where status = 'Cancelled';

-- 2）Find out all of the company's aircraft orders and identify the customers who ordered the most so we can give them discounts or promotions.
select productName, productLine
from products
where productLine regexp 'Planes';


#1.6 Subquery
-- 1）  Who are the customers that each sales rep is responsible for?
select e.firstname,e.lastname,c.customername
from (select *
from employees
where  jobtitle='Sales Rep'
)as e
left join  customers c
on e.employeenumber= c.salesrepemployeenumber ;

-- 2）Query  classic cars whose buyprice is higher than the average buy price of all products

select productcode,productname,buyprice
from products
where buyprice >(
select avg(buyprice)
from products) 
and productline='Classic Cars';

-- 3)Qurvey the number of orders placed by each customer
select c.customername,c.customernumber,
(select count(o.ordernumber)
from orders o
where c.customernumber=o.customernumber
group by o.customernumber
) as times
from customers c 
order by times desc;
-- 4）Query products with higher profit than average.
select productName, MSRP-buyPrice AS Profit 
from products 
where MSRP-buyPrice >(
select avg(MSRP-buyPrice)
from products)
order by profit desc ;



